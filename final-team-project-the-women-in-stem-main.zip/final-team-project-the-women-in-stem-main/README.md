# CPSC 224 Final Project: Connect 4

### Project Description:


### Team Information:

- Team Name:  The women in stem
- Students on team: Lindsey Bodenbender, Izzy May, Zobe Murray
- Semester: Spring 2024


