package edu.gonzaga;

import java.awt.*;

public class Player {
    public Color tokenColor;

    public Player() {
    }
}